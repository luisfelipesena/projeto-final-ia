"""
YouBot Controller - Main FSM logic for cube collection task.
Handles search, approach, grasp, navigation to box, drop, and return.
"""

import math
import sys
from controller import Supervisor

from base import Base
from arm import Arm
from gripper import Gripper
from color_classifier import ColorClassifier
from constants import (
    ARENA_CENTER, ARENA_SIZE, KNOWN_OBSTACLES, 
    BOX_POSITIONS, SPAWN_POSITION
)
from routes import get_route_to_box, get_return_route, wrap_angle, color_from_rgb
from occupancy_grid import OccupancyGrid
from fuzzy_navigator import FuzzyNavigator

# MCP Bridge for Claude Code integration (optional)
MCP_BRIDGE_PATH = "/Users/luisfelipesena/Development/Personal/webots-youbot-mcp"
sys.path.insert(0, MCP_BRIDGE_PATH)
try:
    from mcp_bridge import MCPBridge
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False
    print("[MCP] Bridge not available - running without MCP integration")


class YouBotController:
    """Main controller for YouBot cube collection task."""

    def __init__(self):
        self.robot = Supervisor()
        self.time_step = int(self.robot.getBasicTimeStep())

        self.base = Base(self.robot)
        self.arm = Arm(self.robot)
        self.gripper = Gripper(self.robot)

        self._log_times = {}

        # Camera with Recognition
        self.camera = self.robot.getDevice("camera")
        if self.camera:
            self.camera.enable(self.time_step)
            if self.camera.hasRecognition():
                self.camera.recognitionEnable(self.time_step)
                print("[INIT] Camera recognition enabled")
            else:
                print("[INIT] Camera has no recognition capability")

        # Main LiDAR
        self.lidar = self.robot.getDevice("lidar")
        if self.lidar:
            self.lidar.enable(self.time_step)
            self.lidar.enablePointCloud()

        # Lateral and Rear LiDARs
        self.lidar_rear = self.robot.getDevice("lidar_rear")
        if self.lidar_rear:
            self.lidar_rear.enable(self.time_step)
            self.lidar_rear.enablePointCloud()

        self.lidar_left = self.robot.getDevice("lidar_left")
        if self.lidar_left:
            self.lidar_left.enable(self.time_step)
            self.lidar_left.enablePointCloud()

        self.lidar_right = self.robot.getDevice("lidar_right")
        if self.lidar_right:
            self.lidar_right.enable(self.time_step)
            self.lidar_right.enablePointCloud()

        # Distance sensors (rear)
        self.ds_rear = self.robot.getDevice("ds_rear")
        self.ds_rear_left = self.robot.getDevice("ds_rear_left")
        self.ds_rear_right = self.robot.getDevice("ds_rear_right")

        # Distance sensors (lateral)
        self.ds_left = self.robot.getDevice("ds_left")
        self.ds_right = self.robot.getDevice("ds_right")

        # Distance sensors (front)
        self.ds_front = self.robot.getDevice("ds_front")
        self.ds_front_left = self.robot.getDevice("ds_front_left")
        self.ds_front_right = self.robot.getDevice("ds_front_right")

        # Enable all distance sensors
        for ds in [self.ds_rear, self.ds_rear_left, self.ds_rear_right,
                   self.ds_left, self.ds_right,
                   self.ds_front, self.ds_front_left, self.ds_front_right]:
            if ds:
                ds.enable(self.time_step)

        self.navigator = FuzzyNavigator()

        # Color classifier (Neural Network)
        self.color_classifier = ColorClassifier("model/color_model.onnx")

        self.pose = self._initial_pose()
        self.current_target = None
        self.current_color = None
        self.mode = "search"
        self.stage = 0
        self.stage_timer = 0.0
        self.collected = 0
        self.max_cubes = 15

        # Lawnmower search state
        self.search_state = "forward"
        self.search_direction = 1
        self.turn_progress = 0.0

        # Cube tracking
        self.lost_cube_timer = 0.0
        self.locked_cube_angle = None
        self.locked_cube_distance = None

        # GRASP retry mechanism - fallback to horizontal pose after failures
        self._grasp_attempts = 0
        self._current_target_id = None  # Track which cube we're trying to grasp
        self._skipped_cubes = set()  # Cubes that are unreachable (skip after 6 failures)

        self.box_positions = BOX_POSITIONS

        # Grid / path
        self.grid = OccupancyGrid(ARENA_CENTER, ARENA_SIZE, cell_size=0.12)
        self._seed_static_map()
        self._waypoints = []
        self._path_dirty = True
        self.active_goal = None
        self._max_cmd = 0.25

        # MCP Bridge for Claude Code real-time monitoring
        self.mcp = None
        self.delivered = {"red": 0, "green": 0, "blue": 0}
        if MCP_AVAILABLE:
            try:
                self.mcp = MCPBridge(self.robot)
                print("[MCP] Bridge initialized successfully")
            except Exception as e:
                print(f"[MCP] Bridge init failed: {e}")

    def _log_throttled(self, key, msg, interval=1.5):
        """Log message with throttling to avoid spam."""
        try:
            now = self.robot.getTime()
        except Exception:
            now = 0.0
        last = self._log_times.get(key, -1e9)
        if now - last >= interval:
            print(msg)
            self._log_times[key] = now

    # ===== Grid helpers =====
    def _seed_static_map(self):
        """Initialize grid with known obstacles."""
        self.grid.fill_border(OccupancyGrid.OBSTACLE, static=True)
        wall_inflate = 0.25
        for ox, oy, radius in KNOWN_OBSTACLES:
            self.grid.fill_disk(ox, oy, radius + wall_inflate, OccupancyGrid.OBSTACLE, static=True)
        for pos in self.box_positions.values():
            self.grid.fill_disk(pos[0], pos[1], 0.20, OccupancyGrid.BOX, static=True)
        print(
            f"[GRID] size=({self.grid.width}x{self.grid.height}) cell={self.grid.cell_size:.2f} "
            f"bounds=({self.grid.min_x:.2f},{self.grid.min_y:.2f})-({self.grid.max_x:.2f},{self.grid.max_y:.2f})"
        )

    def _set_goal(self, target):
        """Set navigation goal."""
        self.current_target = target
        self.active_goal = target
        self._waypoints = []
        self._path_dirty = True

    def _wall_clearances(self):
        """Get distances to arena walls."""
        x, y, _ = self.pose
        return (
            x - self.grid.min_x,
            self.grid.max_x - x,
            y - self.grid.min_y,
            self.grid.max_y - y,
        )

    def _enforce_boundary_safety(self, vx_cmd, vy_cmd, margin=0.25):
        """Prevent movement toward walls."""
        yaw = self.pose[2]
        dx_world = math.cos(yaw) * vx_cmd - math.sin(yaw) * vy_cmd
        dy_world = math.sin(yaw) * vx_cmd + math.cos(yaw) * vy_cmd

        left, right, bottom, top = self._wall_clearances()
        if left < margin and dx_world < 0:
            dx_world = 0.0
        if right < margin and dx_world > 0:
            dx_world = 0.0
        if bottom < margin and dy_world < 0:
            dy_world = 0.0
        if top < margin and dy_world > 0:
            dy_world = 0.0

        vx_adj = math.cos(yaw) * dx_world + math.sin(yaw) * dy_world
        vy_adj = -math.sin(yaw) * dx_world + math.cos(yaw) * dy_world
        return vx_adj, vy_adj

    def _safe_move(self, vx, vy, omega):
        """Execute movement with safety limits."""
        vals = [vx, vy, omega]
        limits = [self._max_cmd, self._max_cmd, 0.6]  # vx, vy, omega
        safe = []
        for v, lim in zip(vals, limits):
            if v is None or not math.isfinite(v):
                safe.append(0.0)
            else:
                safe.append(max(-lim, min(lim, v)))
        self.base.move(safe[0], safe[1], safe[2])

    def _clamp_cmds(self, vx, vy, omega):
        """Clamp velocity commands."""
        omega = max(-0.5, min(0.5, omega))
        vx = max(-0.18, min(0.18, vx))
        vy = max(-0.14, min(0.14, vy))
        return vx, vy, omega

    def _distance_to_point(self, point):
        """Calculate distance and angle to a point."""
        dx = point[0] - self.pose[0]
        dy = point[1] - self.pose[1]
        distance = math.hypot(dx, dy)
        angle = wrap_angle(math.atan2(dy, dx) - self.pose[2])
        return distance, angle

    def _skip_passed_waypoints(self):
        """
        Skip waypoints that are behind the robot or already within threshold.
        This prevents getting stuck trying to reach waypoints we've passed.
        CRITICAL: Don't skip to a waypoint requiring 180° turn!
        """
        if not hasattr(self, '_return_waypoints') or not self._return_waypoints:
            return

        wp_threshold = 0.45
        max_skip = min(3, len(self._return_waypoints) - 1)  # Reduced from 5 to 3
        skipped = 0

        while self._return_waypoint_idx < len(self._return_waypoints) and skipped < max_skip:
            wp = self._return_waypoints[self._return_waypoint_idx]
            dist, angle = self._distance_to_point(wp)

            # Check NEXT waypoint's angle - don't skip if next requires big turn
            next_idx = self._return_waypoint_idx + 1
            if next_idx < len(self._return_waypoints):
                next_wp = self._return_waypoints[next_idx]
                _, next_angle = self._distance_to_point(next_wp)
                # Don't skip if next waypoint requires > 100° turn
                if abs(next_angle) > math.radians(100):
                    break

            # Skip if within threshold OR if behind us (angle > 120°) and close
            should_skip = False
            if dist < wp_threshold:
                should_skip = True
            elif abs(angle) > math.radians(120) and dist < 0.80:
                # Waypoint is behind us and relatively close - skip it
                # Reduced threshold from 1.0 to 0.80 to be more conservative
                should_skip = True

            if should_skip:
                self._return_waypoint_idx += 1
                skipped += 1
            else:
                break

        if skipped > 0:
            print(f"[RETURN] Skipped {skipped} passed waypoints, now at WP {self._return_waypoint_idx + 1}")

    def _replan_path(self):
        """Recompute A* path to goal."""
        if not self.active_goal:
            self._waypoints = []
            self._path_dirty = False
            return
        path = self.grid.plan_path((self.pose[0], self.pose[1]), self.active_goal)
        self._waypoints = path
        self._path_dirty = False

    def _update_grid_from_lidar(self, lidar_info):
        """Update occupancy grid from LIDAR readings."""
        if not lidar_info["points"]:
            return
        if any(math.isnan(v) for v in self.pose):
            return
            
        robot_x, robot_y, robot_yaw = self.pose
        origin = (robot_x, robot_y)
        
        hit_changed = False
        cy = math.cos(robot_yaw)
        sy = math.sin(robot_yaw)
        
        for lx, ly in lidar_info["points"]:
            wx = robot_x + lx * cy - ly * sy
            wy = robot_y + lx * sy + ly * cy
            
            if math.isnan(wx) or math.isnan(wy):
                continue
                
            if self.grid.raycast(origin, (wx, wy), OccupancyGrid.OBSTACLE):
                hit_changed = True
                
        if hit_changed:
            self._path_dirty = True

    def _check_rear_safety(self, rear_info, margin=0.30):
        """Check if reverse is safe."""
        if not rear_info:
            return True
        
        r = rear_info.get("rear", 2.0)
        rl = rear_info.get("rear_left", 2.0)
        rr = rear_info.get("rear_right", 2.0)
        
        if r < margin * 0.8:
            return False
        if rl < margin * 0.6 or rr < margin * 0.6:
            return False
        return True

    def _initial_pose(self):
        """Get initial pose from Webots."""
        try:
            self_node = self.robot.getSelf()
            if self_node:
                pos = self_node.getPosition()
                orient = self_node.getOrientation()
                yaw = math.atan2(orient[3], orient[0])
                return [pos[0], pos[1], yaw]
        except Exception as e:
            print(f"[POSE] Error getting initial pose: {e}")
        return [0.0, 0.0, 0.0]

    def _get_ground_truth_pose(self):
        """Get ground truth pose from Webots (for odometry correction)."""
        try:
            self_node = self.robot.getSelf()
            if self_node:
                pos = self_node.getPosition()
                orient = self_node.getOrientation()
                yaw = math.atan2(orient[3], orient[0])
                return [pos[0], pos[1], yaw]
        except Exception:
            pass
        return None

    def _integrate_pose(self, vx, vy, omega, dt):
        """Integrate odometry with NaN protection."""
        if math.isnan(vx) or math.isnan(vy) or math.isnan(omega):
            return

        if any(math.isnan(v) for v in self.pose):
            gt = self._get_ground_truth_pose()
            if gt:
                self.pose = gt
                print(f"[POSE] Recovered from ground truth: ({gt[0]:.2f}, {gt[1]:.2f})")
            else:
                self.pose = [0.0, 0.0, 0.0]
            return

        yaw = self.pose[2]
        dx_world = math.cos(yaw) * vx - math.sin(yaw) * vy
        dy_world = math.sin(yaw) * vx + math.cos(yaw) * vy

        new_x = self.pose[0] + dx_world * dt
        new_y = self.pose[1] + dy_world * dt
        new_yaw = wrap_angle(self.pose[2] + omega * dt)

        if not (math.isnan(new_x) or math.isnan(new_y) or math.isnan(new_yaw)):
            self.pose[0] = new_x
            self.pose[1] = new_y
            self.pose[2] = new_yaw
        else:
            gt = self._get_ground_truth_pose()
            if gt:
                self.pose = gt

    def _process_recognition(self, lock_color=None, lock_angle=None):
        """Process camera recognition for cube detection."""
        if not self.camera or not self.camera.hasRecognition():
            return None

        objects = self.camera.getRecognitionObjects()
        if not objects:
            return None

        best = None
        best_score = float('inf')

        for obj in objects:
            pos = obj.getPosition()
            colors = obj.getColors()

            dist = math.sqrt(pos[0]**2 + pos[1]**2)
            angle = math.atan2(pos[1], pos[0]) if pos[0] != 0 else 0

            color = None
            confidence = 0.0
            if colors:
                try:
                    r, g, b = colors[0], colors[1], colors[2]
                    color, confidence = self.color_classifier.predict_from_rgb(r, g, b)
                    if confidence < 0.5:
                        color = color_from_rgb(r, g, b)
                except Exception:
                    color = None

            if lock_color and color != lock_color:
                continue

            score = dist
            if lock_angle is not None:
                angle_diff = abs(wrap_angle(angle - lock_angle))
                if angle_diff < math.radians(10):
                    score -= 10.0
                else:
                    score += 5.0

            if score < best_score and dist < 2.5:
                best_score = score
                best = {
                    "color": color,
                    "distance": dist,
                    "angle": angle,
                    "position": pos,
                }

        return best

    def _process_lidar(self):
        """Process all LIDARs and fuse into single point cloud."""
        fused_points = []
        
        def process_sensor(sensor, dx, dy, dtheta):
            if not sensor:
                return 2.0, []
            ranges = sensor.getRangeImage()
            if not ranges:
                return 2.0, []
            
            res = sensor.getHorizontalResolution()
            fov = sensor.getFov()
            angle_step = fov / max(1, res - 1)
            min_dist = 2.0
            sensor_points = []
            
            center_idx = len(ranges) // 2
            fov_deg = math.degrees(fov)
            if fov_deg > 0:
                window = int(len(ranges) * (40.0 / fov_deg) / 2)
            else:
                window = 5
            window = max(1, window)
            
            start = max(0, center_idx - window)
            end = min(len(ranges), center_idx + window)
            
            center_vals = [r for r in ranges[start:end] if not (math.isinf(r) or math.isnan(r))]
            if center_vals:
                min_dist = min(center_vals)
            
            for i, r in enumerate(ranges):
                if math.isinf(r) or math.isnan(r) or r <= 0.1:
                    continue
                
                alpha = -fov / 2.0 + i * angle_step
                sx = r * math.cos(alpha)
                sy = r * math.sin(alpha)
                rx = dx + sx * math.cos(dtheta) - sy * math.sin(dtheta)
                ry = dy + sx * math.sin(dtheta) + sy * math.cos(dtheta)
                sensor_points.append((rx, ry))
                
            return min_dist, sensor_points

        front_dist, p_front = process_sensor(self.lidar, 0.28, 0.0, 0.0)
        fused_points.extend(p_front)
        
        rear_dist, p_rear = process_sensor(self.lidar_rear, -0.29, 0.0, math.pi)
        fused_points.extend(p_rear)
        
        left_dist, p_left = process_sensor(self.lidar_left, 0.0, 0.22, math.pi/2)
        fused_points.extend(p_left)
        
        right_dist, p_right = process_sensor(self.lidar_right, 0.0, -0.22, -math.pi/2)
        fused_points.extend(p_right)
        
        return {
            "front": front_dist,
            "rear": rear_dist,
            "left": left_dist,
            "right": right_dist,
            "points": fused_points
        }

    def _process_rear_sensors(self):
        """Process rear distance sensors."""
        def raw_to_meters(raw_value):
            if raw_value is None or math.isnan(raw_value):
                return 2.0
            return max(0.05, min(2.0, raw_value / 1000.0))

        rear = 2.0
        rear_left = 2.0
        rear_right = 2.0
        
        if self.ds_rear:
            rear = raw_to_meters(self.ds_rear.getValue())
        if self.ds_rear_left:
            rear_left = raw_to_meters(self.ds_rear_left.getValue())
        if self.ds_rear_right:
            rear_right = raw_to_meters(self.ds_rear_right.getValue())

        return {"rear": rear, "rear_left": rear_left, "rear_right": rear_right}

    def _process_lateral_sensors(self):
        """Process lateral distance sensors."""
        def raw_to_meters(raw_value):
            if raw_value is None or math.isnan(raw_value):
                return 2.0
            return max(0.05, min(2.0, raw_value / 1000.0))

        left = 2.0
        right = 2.0
        
        if self.ds_left:
            left = raw_to_meters(self.ds_left.getValue())
        if self.ds_right:
            right = raw_to_meters(self.ds_right.getValue())

        return {"left": left, "right": right}

    def _process_front_sensors(self):
        """Process front distance sensors."""
        def raw_to_meters(raw_value):
            if raw_value is None or math.isnan(raw_value):
                return 2.0
            return max(0.05, min(2.0, raw_value / 1000.0))

        front = 2.0
        front_left = 2.0
        front_right = 2.0

        if self.ds_front:
            front = raw_to_meters(self.ds_front.getValue())
        if self.ds_front_left:
            front_left = raw_to_meters(self.ds_front_left.getValue())
        if self.ds_front_right:
            front_right = raw_to_meters(self.ds_front_right.getValue())

        return {"front": front, "front_left": front_left, "front_right": front_right}

    def _check_obstacle_ahead(self, lidar_front, threshold=0.5):
        """Check for obstacles ahead using multiple sources."""
        if lidar_front < threshold:
            return True

        left, right, bottom, top = self._wall_clearances()
        if min(left, right, bottom, top) < threshold:
            return True

        x, y, yaw = self.pose
        for ox, oy, radius in KNOWN_OBSTACLES:
            dx = ox - x
            dy = oy - y
            dist = math.hypot(dx, dy)
            obs_angle = wrap_angle(math.atan2(dy, dx) - yaw)

            if abs(obs_angle) < math.radians(40) and dist < (threshold + radius + 0.1):
                return True

        return False

    def _search_navigation(self, lidar_info, dt):
        """Exploration-based search navigation using search goals + A*."""
        current_time = self.robot.getTime()

        # Wall safety: back away before attempting turns/paths
        left_wall, right_wall, bottom_wall, top_wall = self._wall_clearances()
        min_wall = min(left_wall, right_wall, bottom_wall, top_wall)
        if min_wall < 0.25:
            return -0.10, 0.0, 0.0

        # ===== Initialize explorer state once =====
        if not hasattr(self, "_search_goals"):
            # Safe exploration goals distributed across the arena
            self._search_goals = [
                (-3.20, 1.00),
                (-3.20, -1.00),
                (-1.80, 0.00),
                (-0.20, 1.20),
                (-0.20, -1.20),
                (1.20, 1.00),
                (1.20, -1.00),
                (2.00, 0.60),
                (2.00, -0.60),
            ]
            self._search_goal_idx = 0
            self._search_path = []
            self._search_path_idx = 0
            self._search_last_plan_time = -1e9
            self._search_nav_last_pos = (self.pose[0], self.pose[1])
            self._search_nav_stuck_time = current_time
            self._search_stuck_count = 0
            g = self._search_goals[self._search_goal_idx]
            print(f"[SEARCH] Explorer goal {self._search_goal_idx + 1}/{len(self._search_goals)}: ({g[0]:.2f}, {g[1]:.2f})")

        # Consolidate sensor distances
        front_obs = lidar_info.get("front", 2.0)
        rear_obs = lidar_info.get("rear", 2.0)
        left_obs = lidar_info.get("left", 2.0)
        right_obs = lidar_info.get("right", 2.0)
        min_front = front_obs
        min_rear = rear_obs

        # ===== Stuck detection (search) =====
        moved = math.hypot(
            self.pose[0] - self._search_nav_last_pos[0],
            self.pose[1] - self._search_nav_last_pos[1],
        )
        if moved > 0.15:
            self._search_nav_last_pos = (self.pose[0], self.pose[1])
            self._search_nav_stuck_time = current_time
            self._search_stuck_count = 0
        elif current_time - self._search_nav_stuck_time > 10.0:
            self._search_stuck_count += 1
            self._search_nav_last_pos = (self.pose[0], self.pose[1])
            self._search_nav_stuck_time = current_time

            # Force replan; if repeatedly stuck, switch goal
            self._search_path = []
            self._search_path_idx = 0
            self._search_last_plan_time = -1e9
            if self._search_stuck_count >= 2:
                self._search_goal_idx = (self._search_goal_idx + 1) % len(self._search_goals)
                self._search_stuck_count = 0
                g = self._search_goals[self._search_goal_idx]
                print(f"[SEARCH] Stuck -> switching goal {self._search_goal_idx + 1}/{len(self._search_goals)}: ({g[0]:.2f}, {g[1]:.2f})")
            else:
                g = self._search_goals[self._search_goal_idx]
                print(f"[SEARCH] Stuck -> replanning to goal ({g[0]:.2f}, {g[1]:.2f})")

            # Small escape impulse
            if min_rear > 0.35:
                omega_escape = 0.35 if left_obs > right_obs else -0.35
                return -0.08, 0.0, omega_escape

        # ===== Goal management =====
        goal = self._search_goals[self._search_goal_idx]
        dist_to_goal = math.hypot(goal[0] - self.pose[0], goal[1] - self.pose[1])

        if dist_to_goal < 0.55:
            self._search_goal_idx = (self._search_goal_idx + 1) % len(self._search_goals)
            self._search_path = []
            self._search_path_idx = 0
            self._search_last_plan_time = -1e9
            goal = self._search_goals[self._search_goal_idx]
            print(f"[SEARCH] Explorer goal {self._search_goal_idx + 1}/{len(self._search_goals)}: ({goal[0]:.2f}, {goal[1]:.2f})")
            return 0.0, 0.0, 0.0

        # ===== Path planning (A*) =====
        need_plan = (not self._search_path) or (self._search_path_idx >= len(self._search_path))
        if need_plan and (current_time - self._search_last_plan_time > 0.8):
            path = self.grid.plan_path((self.pose[0], self.pose[1]), goal)
            self._search_last_plan_time = current_time
            self._search_path = path
            self._search_path_idx = 0

            # If no path and not already at goal, switch goal
            if not path and dist_to_goal > 0.70:
                self._search_goal_idx = (self._search_goal_idx + 1) % len(self._search_goals)
                self._search_path = []
                self._search_path_idx = 0
                self._search_last_plan_time = -1e9
                goal = self._search_goals[self._search_goal_idx]
                print(f"[SEARCH] No path -> switching goal {self._search_goal_idx + 1}/{len(self._search_goals)}: ({goal[0]:.2f}, {goal[1]:.2f})")
                return 0.0, 0.0, 0.25

        # Current waypoint (fallback to goal if path is empty)
        if self._search_path and self._search_path_idx < len(self._search_path):
            target_wp = self._search_path[self._search_path_idx]
        else:
            target_wp = goal

        dist_to_wp, angle_to_wp = self._distance_to_point(target_wp)

        # Advance waypoint if reached
        if self._search_path and dist_to_wp < 0.45 and self._search_path_idx < len(self._search_path):
            self._search_path_idx += 1
            if self._search_path_idx < len(self._search_path):
                target_wp = self._search_path[self._search_path_idx]
                dist_to_wp, angle_to_wp = self._distance_to_point(target_wp)

        # ===== Car-like navigation toward waypoint (RETURN-style) =====
        left_blocked = left_obs < 0.20
        right_blocked = right_obs < 0.20

        cmd_speed = 0.0
        cmd_omega = 0.0

        # Emergency front stop
        if min_front < 0.22:
            rear_all_clear = min_rear > 0.30
            if rear_all_clear:
                cmd_speed = -0.08
                if not left_blocked and (right_blocked or left_obs > right_obs):
                    cmd_omega = 0.4
                elif not right_blocked:
                    cmd_omega = -0.4
            else:
                cmd_speed = 0.0
                if not left_blocked:
                    cmd_omega = 0.5
                elif not right_blocked:
                    cmd_omega = -0.5

        # Front danger
        elif min_front < 0.35:
            rear_all_clear = min_rear > 0.30
            if rear_all_clear:
                cmd_speed = -0.06
                if not left_blocked and (right_blocked or left_obs > right_obs):
                    cmd_omega = 0.4
                elif not right_blocked:
                    cmd_omega = -0.4
            else:
                cmd_speed = 0.02
                if not left_blocked and (right_blocked or left_obs > right_obs):
                    cmd_omega = 0.4
                elif not right_blocked:
                    cmd_omega = -0.4

        # Rotate toward waypoint if largely misaligned
        elif abs(angle_to_wp) > math.radians(80):
            cmd_speed = 0.04 if min_front > 0.40 else 0.0
            cmd_omega = -0.45 if angle_to_wp > 0 else 0.45

        # Normal navigation
        else:
            cmd_omega = -angle_to_wp * 1.2
            cmd_omega = max(-0.40, min(0.40, cmd_omega))

            # Lateral repulsion
            if left_obs < 0.35:
                cmd_omega -= 0.15
            if right_obs < 0.35:
                cmd_omega += 0.15
            cmd_omega = max(-0.45, min(0.45, cmd_omega))

            cmd_speed = 0.12
            turn_penalty = 1.0 - min(0.3, abs(cmd_omega) / 0.45)
            cmd_speed *= turn_penalty

        # Final safety: never turn into a blocked side
        if left_blocked and cmd_omega > 0:
            cmd_omega = -0.35
            cmd_speed = min(cmd_speed, 0.03)
        if right_blocked and cmd_omega < 0:
            cmd_omega = 0.35
            cmd_speed = min(cmd_speed, 0.03)

        # Both sides blocked
        if left_blocked and right_blocked:
            cmd_omega = 0.0
            if min_front > 0.35:
                cmd_speed = 0.04
            elif min_rear > 0.30:
                cmd_speed = -0.06
            else:
                cmd_speed = 0.0

        return cmd_speed, 0.0, cmd_omega

    def _start_grasp(self):
        """Begin grasp sequence."""
        self.mode = "grasp"
        self.stage = 0
        self.stage_timer = 0.0
        self.base.reset()
        print(f"[GRASP] Starting capture - color={self.current_color}")

    def _start_drop(self):
        """Begin drop sequence."""
        self.mode = "drop"
        self.stage = 0
        self.stage_timer = 0.0
        self.base.reset()

    def _handle_grasp(self, dt):
        """Handle grasp state machine."""
        self.stage_timer += dt

        if not hasattr(self, '_grasp_forward_time'):
            dist = self.locked_cube_distance if self.locked_cube_distance else 0.25
            # Short pose reaches ~0.10m less than extended poses
            current_pose = self.arm.current_height
            reach_offset = 0.22 if current_pose == Arm.FRONT_FLOOR_SHORT else 0.12
            forward_needed = dist - reach_offset
            forward_needed = max(0.05, min(0.25, forward_needed))
            self._grasp_forward_time = forward_needed / 0.04
            self._grasp_samples = []
            print(f"[GRASP] Forward distance: {forward_needed:.2f}m ({self._grasp_forward_time:.1f}s) (cube at {dist:.2f}m)")

        if self.stage == 0:
            self.gripper.release()
            self.arm.set_height(Arm.RESET)
            if self.stage_timer >= 1.2:
                self.stage += 1
                self.stage_timer = 0.0

        elif self.stage == 1:
            # Track cube identity and select pose based on attempt count
            cube_id = (round(self.active_goal[0], 2), round(self.active_goal[1], 2)) if self.active_goal else None
            if cube_id and cube_id != self._current_target_id:
                self._current_target_id = cube_id
                self._grasp_attempts = 0
                print(f"[GRASP] New target cube at {cube_id}")

            # Detect obstacles near cube (deposit boxes)
            front_obs = self._process_front_sensors()
            min_front = min(front_obs["front"], front_obs["front_left"], front_obs["front_right"])
            obstacle_near_cube = min_front < 0.40 and self.locked_cube_distance and abs(min_front - self.locked_cube_distance) < 0.20

            # Select pose: short if obstacle detected, horizontal after 3 fails, extended by default
            if obstacle_near_cube:
                self.arm.set_height(Arm.FRONT_FLOOR_SHORT)
                if self.stage_timer < 0.1:
                    print(f"[GRASP] Attempt {self._grasp_attempts+1}/6: Using SHORT pose (obstacle at {min_front:.2f}m)")
            elif self._grasp_attempts >= 3:
                self.arm.set_height(Arm.FRONT_CARDBOARD_BOX)
                if self.stage_timer < 0.1:
                    print(f"[GRASP] Attempt {self._grasp_attempts+1}/6: Using HORIZONTAL pose (retry)")
            else:
                self.arm.set_height(Arm.FRONT_FLOOR)
                if self.stage_timer < 0.1:
                    print(f"[GRASP] Attempt {self._grasp_attempts+1}/6: Using EXTENDED pose")

            if self.stage_timer >= 2.0:
                self.stage += 1
                self.stage_timer = 0.0

        elif self.stage == 2:
            omega_cmd = 0.0
            locked_recognition = self._process_recognition(
                lock_color=self.current_color,
                lock_angle=self.locked_cube_angle
            )
            if locked_recognition:
                cam_angle = locked_recognition["angle"]
                omega_cmd = -cam_angle * 0.8
                omega_cmd = max(-0.3, min(0.3, omega_cmd))

            self._safe_move(0.04, 0.0, omega_cmd)
            if self.stage_timer >= self._grasp_forward_time:
                self.base.reset()
                self.stage += 1
                self.stage_timer = 0.0
                print("[GRASP] Stopped, closing gripper...")

        elif self.stage == 3:
            self.gripper.grip()
            if self.stage_timer >= 1.2:
                self.stage += 1
                self.stage_timer = 0.0
                self._grasp_samples = []

        elif self.stage == 4:
            self.arm.set_height(Arm.FRONT_PLATE)
            self.gripper.grip()

            left, right = self.gripper.finger_positions()
            if left is not None:
                self._grasp_samples.append(left)
            if right is not None:
                self._grasp_samples.append(right)

            if self.stage_timer >= 1.5:
                has_obj = self.gripper.has_object()

                if self._grasp_samples:
                    avg_pos = sum(self._grasp_samples) / len(self._grasp_samples)
                    max_pos = max(self._grasp_samples) if self._grasp_samples else 0
                    print(f"[GRASP] Verification: avg={avg_pos:.4f}, max={max_pos:.4f}, has_object={has_obj}")
                else:
                    print(f"[GRASP] No samples, has_object={has_obj}")

                self.base.reset()
                self._grasp_verified = has_obj
                self.stage += 1
                self.stage_timer = 0.0

        elif self.stage == 5:
            has_obj = getattr(self, '_grasp_verified', True)

            if hasattr(self, '_grasp_forward_time'):
                del self._grasp_forward_time
            if hasattr(self, '_grasp_samples'):
                del self._grasp_samples
            if hasattr(self, '_grasp_verified'):
                del self._grasp_verified

            if has_obj:
                # Success - reset attempts counter
                self._grasp_attempts = 0
                self._current_target_id = None

                self.collected += 1
                print(f"[GRASP] Cube captured! Total: {self.collected}/{self.max_cubes}")

                self.locked_cube_distance = None
                if self.active_goal:
                    cell = self.grid.world_to_cell(*self.active_goal)
                    if cell:
                        self.grid.set(cell[0], cell[1], OccupancyGrid.FREE, overwrite_static=False)
                        self._path_dirty = True

                gt = self._get_ground_truth_pose()
                if gt:
                    self.pose = gt
                    print(f"[TO_BOX] Ground truth sync: ({gt[0]:.2f}, {gt[1]:.2f}, {math.degrees(gt[2]):.1f}°)")

                self.mode = "to_box"
                self.stage = 0
                self.stage_timer = 0.0
                color_key = (self.current_color or "").lower()
                target_box = self.box_positions.get(color_key, None)
                if target_box:
                    dist_to_box = math.hypot(target_box[0] - self.pose[0], target_box[1] - self.pose[1])
                    angle_to_box = wrap_angle(math.atan2(target_box[1] - self.pose[1], target_box[0] - self.pose[0]) - self.pose[2])
                    print(f"[TO_BOX] Going to box {color_key.upper()} at {target_box}")
                    print(f"[TO_BOX] Current pose: ({self.pose[0]:.2f}, {self.pose[1]:.2f}, {math.degrees(self.pose[2]):.1f}°) dist={dist_to_box:.2f}m ang={math.degrees(angle_to_box):.1f}°")
                    self._set_goal(target_box)
                else:
                    fallback = list(self.box_positions.values())[0]
                    print(f"[TO_BOX] Color '{self.current_color}' not found, using fallback {fallback}")
                    self._set_goal(fallback)
            else:
                # Failure - increment attempts
                self._grasp_attempts += 1

                if self._grasp_attempts >= 6:
                    # Skip this cube after 6 failed attempts
                    cube_id = self._current_target_id
                    if cube_id:
                        self._skipped_cubes.add(cube_id)
                    print(f"[GRASP] SKIP cube after {self._grasp_attempts} failed attempts - cube unreachable")
                    self._grasp_attempts = 0
                    self._current_target_id = None
                    self.gripper.release()
                    self.mode = "search"
                    self.stage = 0
                    self.stage_timer = 0.0
                    self.current_color = None
                    self.locked_cube_angle = None
                    self.locked_cube_distance = None
                    self.current_target = None
                    self.active_goal = None
                    self._waypoints = []
                    self._path_dirty = True
                else:
                    print(f"[GRASP] FAILED attempt {self._grasp_attempts}/6 - reversing to retry")
                    self.gripper.release()
                    self.stage += 1
                    self.stage_timer = 0.0

        elif self.stage == 6:
            self.arm.set_height(Arm.FRONT_PLATE)
            self._safe_move(-0.06, 0.0, 0.0)
            if self.stage_timer >= 2.0:
                self.base.reset()
                print("[GRASP] Reverse complete, returning to search")
                self.mode = "search"
                self.stage = 0
                self.stage_timer = 0.0
                self.current_color = None
                self.locked_cube_angle = None
                self.locked_cube_distance = None
                self.current_target = None
                self.active_goal = None
                self._waypoints = []
                self._path_dirty = True

    def _handle_drop(self, dt):
        """Handle drop state machine."""
        self.stage_timer += dt

        if self.stage == 0:
            self.arm.set_height(Arm.FRONT_FLOOR)
            self.gripper.grip()
            if self.stage_timer >= 2.0:
                self.stage += 1
                self.stage_timer = 0.0
                print("[DROP] Arm lowered, advancing over box...")

        elif self.stage == 1:
            self._safe_move(0.03, 0.0, 0.0)
            self.gripper.grip()
            if self.stage_timer >= 1.5:
                self.base.reset()
                self.stage += 1
                self.stage_timer = 0.0
                print("[DROP] Over box, releasing cube...")

        elif self.stage == 2:
            self.gripper.release()
            if self.stage_timer >= 1.0:
                self.stage += 1
                self.stage_timer = 0.0

        elif self.stage == 3:
            self._safe_move(-0.06, 0.0, 0.0)
            if self.stage_timer >= 1.0:
                self.base.reset()
                self.stage += 1
                self.stage_timer = 0.0

        elif self.stage == 4:
            self.arm.set_height(Arm.RESET)
            if self.stage_timer >= 1.5:
                self.stage += 1
                self.stage_timer = 0.0
                print("[DROP] Retreating...")

        elif self.stage == 5:
            self._safe_move(-0.10, 0.0, 0.0)
            if self.stage_timer >= 2.0:
                self.base.reset()
                self.stage += 1
                self.stage_timer = 0.0

        elif self.stage == 6:
            # Longer retreat from box
            self._safe_move(-0.12, 0.0, 0.0)
            if self.stage_timer >= 2.5:
                self.base.reset()
                self.stage += 1
                self.stage_timer = 0.0
                # Determine turn direction based on box color
                color = (self.current_color or "").lower()
                if color == "red":
                    # RED box is EAST, turn LEFT (toward WEST)
                    self._post_drop_turn_dir = 1  # positive = left
                    self._post_drop_turn_target = 2.5  # ~140° turn
                elif color == "green":
                    # GREEN box is NORTH, turn RIGHT (toward SOUTH/WEST)
                    self._post_drop_turn_dir = -1
                    self._post_drop_turn_target = 2.0  # ~115° turn
                elif color == "blue":
                    # BLUE box is SOUTH, turn LEFT (toward NORTH/WEST)
                    self._post_drop_turn_dir = 1
                    self._post_drop_turn_target = 2.0
                else:
                    self._post_drop_turn_dir = 1
                    self._post_drop_turn_target = 1.5
                print(f"[DROP] Retreating done. Turning away from {color.upper()} box...")

        elif self.stage == 7:
            # Turn away from box before searching
            turn_dir = getattr(self, '_post_drop_turn_dir', 1)
            turn_target = getattr(self, '_post_drop_turn_target', 2.0)

            self._safe_move(0.0, 0.0, 0.5 * turn_dir)

            if self.stage_timer >= turn_target:
                self.base.reset()
                self.stage += 1
                self.stage_timer = 0.0

        elif self.stage == 8:
            color_key = (self.current_color or "").lower()
            if color_key in self.delivered:
                self.delivered[color_key] += 1

            # Sync ground truth after deposit
            gt = self._get_ground_truth_pose()
            if gt:
                self.pose = gt

            print(f"[DROP] Cube deposited in {self.current_color.upper()} box! (delivered: {self.delivered})")
            print(f"[DROP] Current position: ({self.pose[0]:.2f}, {self.pose[1]:.2f})")
            print("[DROP] Navigating away from box, then searching...")

            # Navigate away from box area before searching (use return_to_spawn waypoints)
            self._last_box_color = color_key
            self.mode = "return_to_spawn"

            # Clear state
            self.current_target = None
            self.active_goal = None
            self._waypoints = []
            self._path_dirty = True
            self.current_color = None
            self.locked_cube_angle = None
            self.locked_cube_distance = None
            # Cleanup post-drop turn state
            for attr in ['_post_drop_turn_dir', '_post_drop_turn_target']:
                if hasattr(self, attr):
                    delattr(self, attr)
            self.base.reset()
            self.stage = 0

    def _handle_return_to_spawn(self, dt, lidar_info, rear_info, lateral_info, front_info):
        """
        Handle return to spawn navigation using strategic waypoints.
        
        Key fix: Use waypoint-following navigation similar to TO_BOX mode,
        with car-like constraints to prevent 180-degree spins.
        """
        self.arm.set_height(Arm.RESET)
        self.gripper.release()

        current_time = self.robot.getTime()

        # Initialization
        if not hasattr(self, '_return_phase'):
            self._return_phase = 0  # 0=retreat, 1=turn-in-place, 2=navigate
            self._return_start = current_time
            self._return_log_time = 0.0
            self._return_turn_start = None
            self._return_last_angle = None

            print("[RETURN] Phase 0: Retreating from box...")

        # Sensor consolidation
        rear_obs = min(lidar_info["rear"], rear_info.get("rear", 2.0))
        rl_obs = rear_info.get("rear_left", 2.0)
        rr_obs = rear_info.get("rear_right", 2.0)
        left_obs = min(lidar_info["left"], lateral_info.get("left", 2.0))
        right_obs = min(lidar_info["right"], lateral_info.get("right", 2.0))
        front_obs = min(lidar_info["front"], front_info["front"])
        fl_obs = front_info.get("front_left", 2.0)
        fr_obs = front_info.get("front_right", 2.0)

        min_rear = min(rear_obs, rl_obs, rr_obs)
        min_front = min(front_obs, fl_obs, fr_obs)

        dist_to_spawn, angle_to_spawn = self._distance_to_point(SPAWN_POSITION)

        # ===== PHASE 0: RETREAT FROM BOX =====
        if self._return_phase == 0:
            phase_elapsed = current_time - self._return_start

            if not hasattr(self, '_retreat_start_pos'):
                self._retreat_start_pos = (self.pose[0], self.pose[1])
                self._retreat_substage = 0  # 0=reverse, 1=turn+forward, 2=done

                # Check if already far from box - skip retreat if so
                # DROP stages 6-7 already did retreat, additional phase 0 retreat
                # can push robot INTO obstacle zones (especially near obstacle A)
                color_key = getattr(self, '_last_box_color', 'red')
                box_pos = BOX_POSITIONS.get(color_key, (0, 0))
                dist_from_box = math.hypot(
                    self.pose[0] - box_pos[0],
                    self.pose[1] - box_pos[1]
                )
                if dist_from_box > 0.80:
                    print(f"[RETURN] Already {dist_from_box:.2f}m from box, skipping retreat")
                    self._retreat_substage = 2  # Skip directly to done

            retreat_dist = math.hypot(
                self.pose[0] - self._retreat_start_pos[0],
                self.pose[1] - self._retreat_start_pos[1]
            )

            rear_clear = min_rear > 0.25 and rl_obs > 0.25 and rr_obs > 0.25
            front_clear = min_front > 0.35

            # Substage 0: Try to reverse
            if self._retreat_substage == 0:
                if retreat_dist < 0.40 and phase_elapsed < 3.0 and rear_clear:
                    self._safe_move(-0.12, 0.0, 0.0)
                    return
                else:
                    # Rear blocked or retreated enough, try turning + forward
                    if retreat_dist < 0.20 and front_clear:
                        # Didn't retreat enough, try turning and moving forward
                        self._retreat_substage = 1
                        self._retreat_turn_start = current_time
                        color_key = getattr(self, '_last_box_color', 'red')
                        # Turn right for red (go south), left for others
                        self._retreat_turn_dir = -0.4 if color_key == 'red' else 0.4
                        print("[RETURN] Rear blocked, turning to escape...")
                    else:
                        self._retreat_substage = 2  # Done

            # Substage 1: Turn and move forward to escape
            if self._retreat_substage == 1:
                turn_elapsed = current_time - self._retreat_turn_start
                if turn_elapsed < 2.5 and front_clear:
                    # Turn while moving forward slightly
                    self._safe_move(0.06, 0.0, self._retreat_turn_dir)
                    return
                else:
                    self._retreat_substage = 2  # Done

            # Substage 2: Finish retreat phase
            if self._retreat_substage == 2:
                # Cleanup retreat state
                for attr in ['_retreat_start_pos', '_retreat_substage', 
                             '_retreat_turn_start', '_retreat_turn_dir']:
                    if hasattr(self, attr):
                        delattr(self, attr)

                # Sync ground truth AFTER retreat (critical fix!)
                gt = self._get_ground_truth_pose()
                if gt:
                    self.pose = gt

                # NOW calculate the route from actual position
                color_key = getattr(self, '_last_box_color', 'red')
                self._return_waypoints = get_return_route((self.pose[0], self.pose[1]), color_key)
                self._return_waypoint_idx = 0
                
                # Skip waypoints that are already behind or too close
                self._skip_passed_waypoints()
                
                print(f"[RETURN] Retreated {retreat_dist:.2f}m. Current pos: ({self.pose[0]:.2f}, {self.pose[1]:.2f})")
                print(f"[RETURN] Strategic route calculated: {len(self._return_waypoints)} waypoints")
                for i, wp in enumerate(self._return_waypoints):
                    marker = " <--" if i == self._return_waypoint_idx else ""
                    print(f"  [{i+1}] ({wp[0]:.2f}, {wp[1]:.2f}){marker}")
                
                print("[RETURN] Phase 1: Turn-in-place check...")
                self._return_phase = 1
                self._return_start = current_time
            return

        # ===== PHASE 1: TURN-IN-PLACE (if needed) =====
        if self._return_phase == 1:
            # Get current waypoint
            if self._return_waypoint_idx < len(self._return_waypoints):
                target_wp = self._return_waypoints[self._return_waypoint_idx]
            else:
                target_wp = SPAWN_POSITION

            dist_to_wp, angle_to_wp = self._distance_to_point(target_wp)

            # Only need to turn if angle > 80 degrees (reduced from 100)
            # KEY FIX: Turn TOWARD the waypoint, not based on box color
            if abs(angle_to_wp) > math.radians(80):
                # Initialize on first iteration - CHOOSE DIRECTION ONCE
                if self._return_turn_start is None:
                    self._return_turn_start = current_time
                    self._return_last_angle = angle_to_wp
                    self._return_turn_attempts = 0

                    color_key = getattr(self, '_last_box_color', 'unknown')
                    # IMPORTANT: Keep sign convention consistent with the rest of navigation:
                    # we generally use omega = -k * angle_to_wp. Therefore:
                    # - angle_to_wp > 0  => waypoint is to the LEFT  => omega should be NEGATIVE
                    # - angle_to_wp < 0  => waypoint is to the RIGHT => omega should be POSITIVE
                    self._return_committed_dir = -1 if angle_to_wp > 0 else 1
                    turn_label = "LEFT" if angle_to_wp > 0 else "RIGHT"
                    print(f"[RETURN] Starting turn {turn_label} toward waypoint (angle={math.degrees(angle_to_wp):.0f}°, from {color_key})")
                
                turn_elapsed = current_time - self._return_turn_start

                # CRITICAL: NEVER change committed direction during same turn.
                # Angle wrapping near ±180° would cause oscillation.
                # Direction is committed once at line 1029/1031 and LOCKED.

                # Stuck detection: if turning for >6s without reaching < 70°
                if turn_elapsed > 6.0:
                    self._return_turn_attempts += 1

                    if self._return_turn_attempts >= 3:
                        # Give up on this waypoint
                        print(f"[RETURN] Turn timeout! Skipping waypoint {self._return_waypoint_idx+1}")
                        self._return_waypoint_idx += 1
                        self._return_turn_start = None
                        self._return_last_angle = None
                        self._return_turn_attempts = 0
                        if hasattr(self, '_return_committed_dir'):
                            delattr(self, '_return_committed_dir')
                        self._skip_passed_waypoints()
                        return
                    else:
                        # Reset timer but KEEP committed direction
                        turn_label = "RIGHT" if self._return_committed_dir > 0 else "LEFT"
                        print(f"[RETURN] Turn attempt {self._return_turn_attempts}, continuing {turn_label}...")
                        self._return_turn_start = current_time
                        # CRITICAL: Do NOT re-evaluate direction. Keep original commitment.
                
                # Use committed direction with obstacle checking
                omega_speed = 0.45
                omega = self._return_committed_dir * omega_speed
                
                # Check if direction is blocked
                if omega > 0 and right_obs < 0.20:
                    omega = omega_speed * 0.3  # Slow down but keep trying
                elif omega < 0 and left_obs < 0.20:
                    omega = -omega_speed * 0.3
                
                # ALWAYS move forward slightly while turning - prevents getting stuck
                fwd = 0.04 if min_front > 0.35 else (-0.04 if min_rear > 0.30 else 0.0)
                
                self._safe_move(fwd, 0.0, omega)
                
                # Log progress
                if current_time - self._return_log_time > 1.0:
                    dir_str = "R" if omega > 0 else "L"
                    print(f"[RETURN] Turning {dir_str}: angle={math.degrees(angle_to_wp):.0f}° (elapsed {turn_elapsed:.1f}s)")
                    self._return_log_time = current_time
                return
            else:
                # Cleanup turn state
                self._return_turn_start = None
                self._return_last_angle = None
                for attr in ['_return_turn_attempts', '_return_committed_dir']:
                    if hasattr(self, attr):
                        delattr(self, attr)
                print("[RETURN] Phase 2: Navigating to spawn...")
                self._return_phase = 2
                self._return_start = current_time

        # ===== PHASE 2: WAYPOINT NAVIGATION (similar to TO_BOX) =====
        if self._return_phase == 2:
            # Arrived at spawn?
            if dist_to_spawn < 0.60:
                print(f"[RETURN] Arrived at spawn! Pose: ({self.pose[0]:.2f}, {self.pose[1]:.2f})")
                print("[RETURN] ========== STARTING NEW SEARCH ==========")

                gt = self._get_ground_truth_pose()
                if gt:
                    self.pose = gt

                # Cleanup
                for attr in ['_return_phase', '_return_start', '_return_log_time',
                             '_return_waypoints', '_return_waypoint_idx', '_last_box_color',
                             '_return_turn_start', '_return_last_angle', '_return_nav_last_pos',
                             '_return_nav_stuck_time', '_return_turn_attempts', '_return_committed_dir']:
                    if hasattr(self, attr):
                        delattr(self, attr)

                self.mode = "search"
                return

            # Track total return time for timeout
            if not hasattr(self, '_return_total_start'):
                self._return_total_start = current_time

            return_elapsed = current_time - self._return_total_start

            # Early transition to search when:
            # 1. In center corridor (safe zone), OR
            # 2. 30s timeout exceeded (fallback safety)
            in_safe_zone = self.pose[0] < -1.15 and abs(self.pose[1]) < 0.8
            timeout_exceeded = return_elapsed > 30.0

            if in_safe_zone or timeout_exceeded:
                reason = "Center corridor reached" if in_safe_zone else f"Timeout ({return_elapsed:.1f}s)"
                print(f"[RETURN] {reason} at ({self.pose[0]:.2f}, {self.pose[1]:.2f}), starting search")
                gt = self._get_ground_truth_pose()
                if gt:
                    self.pose = gt
                # Cleanup return state
                for attr in ['_return_phase', '_return_start', '_return_log_time',
                             '_return_waypoints', '_return_waypoint_idx', '_last_box_color',
                             '_return_turn_start', '_return_last_angle', '_return_nav_last_pos',
                             '_return_nav_stuck_time', '_return_turn_attempts', '_return_committed_dir',
                             '_return_total_start']:
                    if hasattr(self, attr):
                        delattr(self, attr)
                self.mode = "search"
                self.search_state = "forward"
                return

            # Current waypoint
            if self._return_waypoint_idx < len(self._return_waypoints):
                target_wp = self._return_waypoints[self._return_waypoint_idx]
            else:
                target_wp = SPAWN_POSITION

            dist_to_wp, angle_to_wp = self._distance_to_point(target_wp)

            # Advance waypoint if reached
            wp_threshold = 0.45
            if dist_to_wp < wp_threshold and self._return_waypoint_idx < len(self._return_waypoints):
                self._return_waypoint_idx += 1
                # Skip any other passed waypoints
                self._skip_passed_waypoints()
                if self._return_waypoint_idx < len(self._return_waypoints):
                    next_wp = self._return_waypoints[self._return_waypoint_idx]
                    print(f"[RETURN] Waypoint {self._return_waypoint_idx}/{len(self._return_waypoints)} reached -> next: ({next_wp[0]:.2f}, {next_wp[1]:.2f})")
                else:
                    print("[RETURN] All waypoints reached, heading to spawn")
                # Reset stuck tracking
                if hasattr(self, '_return_nav_last_pos'):
                    delattr(self, '_return_nav_last_pos')
                if hasattr(self, '_return_nav_stuck_time'):
                    delattr(self, '_return_nav_stuck_time')
                return

            # Stuck detection in navigation
            if not hasattr(self, '_return_nav_last_pos'):
                self._return_nav_last_pos = (self.pose[0], self.pose[1])
                self._return_nav_stuck_time = current_time
            else:
                moved = math.hypot(
                    self.pose[0] - self._return_nav_last_pos[0],
                    self.pose[1] - self._return_nav_last_pos[1]
                )
                if moved > 0.15:  # Moved more than 15cm
                    self._return_nav_last_pos = (self.pose[0], self.pose[1])
                    self._return_nav_stuck_time = current_time
                elif current_time - self._return_nav_stuck_time > 8.0:
                    # Stuck for 8 seconds, skip to next waypoint
                    print(f"[RETURN] Navigation stuck! Skipping waypoint {self._return_waypoint_idx + 1}")
                    self._return_waypoint_idx += 1
                    self._skip_passed_waypoints()
                    self._return_nav_last_pos = (self.pose[0], self.pose[1])
                    self._return_nav_stuck_time = current_time
                    return

            # Periodic logging
            if current_time - self._return_log_time > 2.0:
                wp_info = f"WP {self._return_waypoint_idx+1}/{len(self._return_waypoints)}" if self._return_waypoint_idx < len(self._return_waypoints) else "SPAWN"
                print(f"[RETURN] Pos: ({self.pose[0]:.2f}, {self.pose[1]:.2f}) -> {wp_info} dist={dist_to_wp:.2f}m ang={math.degrees(angle_to_wp):.0f}°")
                self._return_log_time = current_time

            # ===== CAR-LIKE NAVIGATION (same as TO_BOX) =====
            
            # If angle > 100 degrees, go back to Phase 1 (turn-in-place)
            # This handles cases where we skipped waypoints and now face wrong direction
            if abs(angle_to_wp) > math.radians(100):
                print(f"[RETURN] Waypoint behind ({math.degrees(angle_to_wp):.0f}°), returning to turn-in-place")
                self._return_phase = 1
                self._return_turn_start = None
                self._return_last_angle = None
                return
            
            # If angle still significant (> 70 degrees), rotate while moving slowly
            if abs(angle_to_wp) > math.radians(70):
                omega = -0.40 if angle_to_wp > 0 else 0.40
                fwd = 0.03 if min_front > 0.40 else 0.0
                self._safe_move(fwd, 0.0, omega)
                return

            left_blocked = left_obs < 0.20
            right_blocked = right_obs < 0.20

            # FIX: Check rear clearance before any rotation (prevents rear wheel stuck)
            rear_blocked = min_rear < 0.30 or left_obs < 0.30 or right_obs < 0.30
            if rear_blocked and min_front > 0.30:
                # Rear stuck, front clear - move forward to get clearance
                self._safe_move(0.06, 0.0, 0.0)
                return
            elif rear_blocked and min_front < 0.25:
                # BOTH blocked - strafe to escape
                if left_obs > right_obs:
                    self._safe_move(0.0, 0.08, 0.0)
                else:
                    self._safe_move(0.0, -0.08, 0.0)
                return

            cmd_speed = 0.0
            cmd_omega = 0.0

            # Priority 1: Emergency stop
            if min_front < 0.22:
                rear_all_clear = min_rear > 0.30
                if rear_all_clear:
                    cmd_speed = -0.08
                    if not left_blocked and (right_blocked or left_obs > right_obs):
                        cmd_omega = 0.4
                    elif not right_blocked:
                        cmd_omega = -0.4
                else:
                    cmd_speed = 0.0
                    if not left_blocked:
                        cmd_omega = 0.5
                    elif not right_blocked:
                        cmd_omega = -0.5

            # Priority 2: Front danger
            elif min_front < 0.35:
                rear_all_clear = min_rear > 0.30
                if rear_all_clear:
                    cmd_speed = -0.06
                    if not left_blocked and (right_blocked or left_obs > right_obs):
                        cmd_omega = 0.4
                    elif not right_blocked:
                        cmd_omega = -0.4
                else:
                    cmd_speed = 0.02
                    if not left_blocked and (right_blocked or left_obs > right_obs):
                        cmd_omega = 0.4
                    elif not right_blocked:
                        cmd_omega = -0.4

            # Priority 3: Front warning
            elif min_front < 0.55:
                if left_blocked:
                    cmd_omega = -0.35
                elif right_blocked:
                    cmd_omega = 0.35
                elif left_obs > right_obs + 0.1:
                    cmd_omega = 0.25
                elif right_obs > left_obs + 0.1:
                    cmd_omega = -0.25
                else:
                    cmd_omega = -angle_to_wp * 0.8
                    cmd_omega = max(-0.35, min(0.35, cmd_omega))
                
                cmd_speed = 0.06

            # Priority 4: Normal navigation
            else:
                cmd_omega = -angle_to_wp * 1.2
                cmd_omega = max(-0.40, min(0.40, cmd_omega))
                
                # Lateral repulsion
                if left_obs < 0.35:
                    cmd_omega -= 0.15
                if right_obs < 0.35:
                    cmd_omega += 0.15
                cmd_omega = max(-0.45, min(0.45, cmd_omega))
                
                cmd_speed = 0.12
                turn_penalty = 1.0 - min(0.3, abs(cmd_omega) / 0.45)
                cmd_speed *= turn_penalty

            # Final safety check: never turn into blocked side
            if left_blocked and cmd_omega > 0:
                cmd_omega = -0.35
                cmd_speed = min(cmd_speed, 0.03)
            if right_blocked and cmd_omega < 0:
                cmd_omega = 0.35
                cmd_speed = min(cmd_speed, 0.03)

            # Both sides blocked
            if left_blocked and right_blocked:
                cmd_omega = 0.0
                if min_front > 0.35:
                    cmd_speed = 0.04
                elif min_rear > 0.30:
                    cmd_speed = -0.06
                else:
                    cmd_speed = 0.0

            self._safe_move(cmd_speed, 0.0, cmd_omega)

    def run(self):
        """Main control loop."""
        print("[RUN] YouBot controller started")

        # Move forward at spawn to clear wall
        print("[INIT] Moving forward to clear spawn wall...")
        for _ in range(50):
            if self.robot.step(self.time_step) == -1:
                return
            self.base.move(0.12, 0.0, 0.0)
        self.base.reset()

        gt = self._get_ground_truth_pose()
        if gt:
            self.pose = gt
            print(f"[INIT] Spawn complete. Pose: ({gt[0]:.2f}, {gt[1]:.2f}, {math.degrees(gt[2]):.1f}°)")
        else:
            print("[INIT] Spawn complete (no ground truth)")

        while self.robot.step(self.time_step) != -1:
            dt = self.time_step / 1000.0

            if self.collected >= self.max_cubes:
                print("[DONE] All cubes collected!")
                self.base.reset()
                break

            # Odometry with periodic sync
            vx_odo, vy_odo, omega_odo = self.base.compute_odometry(dt)
            self._integrate_pose(vx_odo, vy_odo, omega_odo, dt)

            if not hasattr(self, '_gt_sync_timer'):
                self._gt_sync_timer = 0.0
            self._gt_sync_timer += dt

            sync_interval = 0.5 if self.mode in ("to_box", "return_to_spawn") else 2.0
            pose_invalid = any(math.isnan(v) for v in self.pose)
            if pose_invalid or self._gt_sync_timer >= sync_interval:
                gt = self._get_ground_truth_pose()
                if gt:
                    if pose_invalid:
                        print(f"[POSE] Invalid pose, syncing: ({gt[0]:.2f}, {gt[1]:.2f}, {math.degrees(gt[2]):.1f}°)")
                    self.pose = gt
                self._gt_sync_timer = 0.0

            # Sensors
            lidar_info = self._process_lidar()
            rear_info = self._process_rear_sensors()
            lateral_info = self._process_lateral_sensors()
            front_info = self._process_front_sensors()
            
            if "rear" in lidar_info:
                rear_info["rear"] = min(rear_info["rear"], lidar_info["rear"])
            
            self._update_grid_from_lidar(lidar_info)

            lock_color = self.current_color if self.mode == "approach" else None
            lock_angle = self.locked_cube_angle if self.mode == "approach" else None
            recognition = self._process_recognition(lock_color=lock_color, lock_angle=lock_angle)

            # MCP Bridge
            if self.mcp:
                left_f, right_f = self.gripper.finger_positions()
                gripper_closed = (left_f or 0) < 0.005 and (right_f or 0) < 0.005
                has_cube = self.gripper.has_object() if not gripper_closed else False

                recog_info = None
                if recognition:
                    recog_info = {"color": recognition["color"], "distance": round(recognition["distance"], 3), "angle": round(recognition["angle"], 2)}

                self.mcp.publish({
                    "pose": self.pose,
                    "mode": self.mode,
                    "collected": self.collected,
                    "max_cubes": self.max_cubes,
                    "delivered": self.delivered,
                    "current_target": self.current_color,
                    "lidar": {"front": lidar_info["front"], "rear": lidar_info["rear"], "left": lidar_info["left"], "right": lidar_info["right"]},
                    "distance_sensors": front_info,
                    "gripper": {"left": left_f, "right": right_f, "closed": gripper_closed, "has_cube": has_cube},
                    "recognition": recog_info,
                    "arm_state": getattr(self, 'arm_state', 'unknown'),
                })
                self.mcp.get_command()

                if hasattr(self, '_mcp_frame_counter'):
                    self._mcp_frame_counter += 1
                else:
                    self._mcp_frame_counter = 0
                if self._mcp_frame_counter % 50 == 0:
                    self.mcp.save_camera_frame(self.camera)

            # ===== MODE: SEARCH =====
            if self.mode == "search":
                left, right, bottom, top = self._wall_clearances()
                near_wall = min(left, right, bottom, top) < 0.35

                if recognition:
                    # Calculate cube world position for skip check
                    cam_dist = recognition["distance"]
                    cam_angle = recognition["angle"]
                    robot_x, robot_y, robot_yaw = self.pose

                    # Camera offset from robot center (~0.27m forward)
                    cam_offset = 0.27
                    cam_world_x = robot_x + cam_offset * math.cos(robot_yaw)
                    cam_world_y = robot_y + cam_offset * math.sin(robot_yaw)

                    # Cube position in world coordinates
                    cube_angle_world = robot_yaw + cam_angle
                    cube_world_x = cam_world_x + cam_dist * math.cos(cube_angle_world)
                    cube_world_y = cam_world_y + cam_dist * math.sin(cube_angle_world)
                    cube_id = (round(cube_world_x, 2), round(cube_world_y, 2))

                    # Skip cube if already marked as unreachable (with proximity check)
                    is_skipped = False
                    for skipped_pos in self._skipped_cubes:
                        dist_to_skipped = math.hypot(cube_world_x - skipped_pos[0], cube_world_y - skipped_pos[1])
                        if dist_to_skipped < 0.25:  # 25cm tolerance for position drift
                            is_skipped = True
                            self._log_throttled("skip_cube", f"[SEARCH] Ignoring skipped cube near {skipped_pos}", 2.0)
                            break

                    if is_skipped:
                        pass  # Continue searching, don't transition to approach
                    else:
                        self.current_color = recognition["color"]
                        self.locked_cube_angle = recognition["angle"]
                        self.active_goal = (cube_world_x, cube_world_y)  # Set for grasp tracking
                        self.mode = "approach"
                        self.lost_cube_timer = 0.0
                        print(f"[SEARCH] Cube detected (color={self.current_color}) dist={cam_dist:.2f}m at {cube_id}, starting approach")
                        continue

                vx_cmd, vy_cmd, omega_cmd = self._search_navigation(lidar_info, dt)
                vx_cmd, vy_cmd, omega_cmd = self._clamp_cmds(vx_cmd, vy_cmd, omega_cmd if not near_wall else 0.0)
                vx_cmd, vy_cmd = self._enforce_boundary_safety(vx_cmd, vy_cmd)
                self._safe_move(vx_cmd, vy_cmd, omega_cmd)
                continue

            # ===== MODE: APPROACH =====
            if self.mode == "approach":
                current_time = self.robot.getTime()
                front_obstacle = min(
                    front_info["front"],
                    front_info["front_left"],
                    front_info["front_right"],
                    lidar_info["front"]
                )

                # Time-based obstacle timeout (doesn't reset on distance fluctuation)
                if not hasattr(self, '_approach_obstacle_start'):
                    self._approach_obstacle_start = None

                if front_obstacle < 0.20:
                    # Check if cube is BEHIND obstacle (unreachable)
                    if recognition and recognition["distance"] > front_obstacle + 0.05:
                        cube_id = None
                        if self.active_goal:
                            cube_id = (round(self.active_goal[0], 2), round(self.active_goal[1], 2))
                        if cube_id:
                            self._skipped_cubes.add(cube_id)
                        print(f"[APPROACH] Cube behind obstacle (cube={recognition['distance']:.2f}m, obstacle={front_obstacle:.2f}m) - skipping")
                        self.mode = "search"
                        self.locked_cube_angle = None
                        self.locked_cube_distance = None
                        self.current_color = None
                        self.current_target = None
                        self.active_goal = None
                        self._approach_obstacle_start = None
                        continue

                    # Start obstacle timer on first encounter
                    if self._approach_obstacle_start is None:
                        self._approach_obstacle_start = current_time

                    obstacle_duration = current_time - self._approach_obstacle_start
                    self._log_throttled("approach_obstacle", f"[APPROACH] FRONT OBSTACLE! dist={front_obstacle:.2f}m, duration={obstacle_duration:.1f}s", 0.5)

                    if front_info["front_left"] > front_info["front_right"]:
                        vy_cmd = 0.08
                        omega_cmd = 0.2
                    else:
                        vy_cmd = -0.08
                        omega_cmd = -0.2

                    self._safe_move(-0.04, vy_cmd, omega_cmd)

                    # Time-based timeout: 8 seconds of continuous obstacle
                    if obstacle_duration > 8.0:
                        cube_id = None
                        if self.active_goal:
                            cube_id = (round(self.active_goal[0], 2), round(self.active_goal[1], 2))
                        if cube_id:
                            self._skipped_cubes.add(cube_id)
                        print(f"[APPROACH] Timeout ({obstacle_duration:.1f}s) avoiding obstacle - cube unreachable")
                        self.mode = "search"
                        self.locked_cube_angle = None
                        self.locked_cube_distance = None
                        self.current_color = None
                        self.current_target = None
                        self.active_goal = None
                        self._approach_obstacle_start = None
                    continue
                else:
                    # Only reset timer if obstacle has been clear for a while (prevents flickering reset)
                    # Keep timer if we just briefly moved past 0.20m threshold
                    pass

                if recognition:
                    self.lost_cube_timer = 0.0
                    cam_dist = recognition["distance"]
                    cam_angle = recognition["angle"]

                    self.locked_cube_distance = cam_dist
                    self.locked_cube_angle = cam_angle

                    grasp_distance = 0.32
                    grasp_angle_max = math.radians(10)

                    if cam_dist < grasp_distance and abs(cam_angle) < grasp_angle_max:
                        print(f"[APPROACH] Cube at {cam_dist:.2f}m, angle={math.degrees(cam_angle):.1f}°, starting grasp")
                        self._start_grasp()
                        continue
                    elif cam_dist < grasp_distance and abs(cam_angle) >= grasp_angle_max:
                        omega_cmd = -cam_angle * 1.0
                        omega_cmd = max(-0.4, min(0.4, omega_cmd))
                        self._safe_move(0.0, 0.0, omega_cmd)
                        self._log_throttled("approach_align_close", f"[APPROACH] Close but misaligned: angle={math.degrees(cam_angle):.1f}°", 1.0)
                        continue

                    angle_threshold = math.radians(5)

                    if abs(cam_angle) > angle_threshold:
                        omega_cmd = -cam_angle * 0.8
                        omega_cmd = max(-0.3, min(0.3, omega_cmd))
                        vx_cmd = 0.0
                        self._log_throttled("approach_align", f"[APPROACH] Aligning: angle={math.degrees(cam_angle):.1f}°, dist={cam_dist:.2f}m", 1.0)
                    else:
                        vx_cmd = 0.08
                        omega_cmd = -cam_angle * 1.2
                        omega_cmd = max(-0.2, min(0.2, omega_cmd))
                        self._log_throttled("approach_advance", f"[APPROACH] Advancing: dist={cam_dist:.2f}m, angle={math.degrees(cam_angle):.1f}°", 1.0)

                    self._safe_move(vx_cmd, 0.0, omega_cmd)
                    continue
                else:
                    self.lost_cube_timer += dt

                    if self.locked_cube_distance is not None and self.locked_cube_distance < 0.35:
                        if self.lost_cube_timer > 0.3:
                            print(f"[APPROACH] Cube lost at {self.locked_cube_distance:.2f}m, starting grasp")
                            self._start_grasp()
                            continue

                    if self.lost_cube_timer > 4.0:
                        print("[APPROACH] Timeout - returning to search")
                        self.mode = "search"
                        self.locked_cube_angle = None
                        self.locked_cube_distance = None
                        self.current_color = None
                        self.lost_cube_timer = 0.0
                        continue

                    if self.locked_cube_angle is not None:
                        omega_recovery = -self.locked_cube_angle * 0.3
                        omega_recovery = max(-0.2, min(0.2, omega_recovery))
                    else:
                        omega_recovery = 0.0
                    self._safe_move(0.08, 0.0, omega_recovery)
                    continue

            # ===== MODE: GRASP =====
            if self.mode == "grasp":
                self._handle_grasp(dt)
                continue

            # ===== MODE: TO_BOX =====
            if self.mode == "to_box":
                self.gripper.grip()
                self.arm.set_height(Arm.RESET)
                
                if not hasattr(self, 'tobox_state'):
                    self.tobox_state = -1  # Start with turn-in-place phase
                    self._tobox_maneuver_timer = 0.0
                    self._route_waypoints = None
                    self._current_waypoint_idx = 0
                    self._tobox_turn_start = None
                    self._tobox_turn_direction = None

                if not self.active_goal:
                    print("[TO_BOX] No goal defined, returning to search")
                    self.mode = "search"
                    continue

                if self._route_waypoints is None:
                    self._route_waypoints = get_route_to_box(
                        (self.pose[0], self.pose[1]), 
                        self.current_color
                    )
                    self._current_waypoint_idx = 0
                    print("[TO_BOX] ===== ROUTE CALCULATED =====")
                    print(f"[TO_BOX] Color: {self.current_color} | Destination: {BOX_POSITIONS.get(self.current_color)}")
                    print(f"[TO_BOX] Waypoints ({len(self._route_waypoints)}):")
                    for i, wp in enumerate(self._route_waypoints):
                        print(f"  [{i+1}] ({wp[0]:.2f}, {wp[1]:.2f})")
                    print("[TO_BOX] =============================")
                
                if not hasattr(self, '_last_pos_log_time'):
                    self._last_pos_log_time = 0.0
                current_time = self.robot.getTime()
                if current_time - self._last_pos_log_time > 2.0:
                    wp_idx = self._current_waypoint_idx
                    wp_total = len(self._route_waypoints)
                    wp_name = f"WP{wp_idx+1}/{wp_total}" if wp_idx < wp_total else "BOX"
                    print(f"[TO_BOX] Pos: ({self.pose[0]:.2f}, {self.pose[1]:.2f}, {math.degrees(self.pose[2]):.0f}°) -> {wp_name}")
                    self._last_pos_log_time = current_time

                front_obs = min(lidar_info["front"], front_info["front"])
                fl_obs = min(lidar_info["front"], front_info.get("front_left", 2.0))
                fr_obs = min(lidar_info["front"], front_info.get("front_right", 2.0))
                rear_obs = min(lidar_info["rear"], rear_info.get("rear", 2.0))
                rear_min = min(rear_obs, rear_info.get("rear_left", 2.0), rear_info.get("rear_right", 2.0))
                left_obs = min(lidar_info["left"], lateral_info.get("left", 2.0))
                right_obs = min(lidar_info["right"], lateral_info.get("right", 2.0))

                if self._current_waypoint_idx < len(self._route_waypoints):
                    current_target = self._route_waypoints[self._current_waypoint_idx]
                else:
                    current_target = self.active_goal
                
                dist_to_waypoint, angle_to_waypoint = self._distance_to_point(current_target)
                dist_to_box, angle_to_box = self._distance_to_point(self.active_goal)
                
                is_final_waypoint = (self._current_waypoint_idx >= len(self._route_waypoints) - 1)
                is_pre_final = (self._current_waypoint_idx == len(self._route_waypoints) - 2)
                
                if is_final_waypoint:
                    waypoint_threshold = 0.50
                elif is_pre_final:
                    waypoint_threshold = 0.30
                else:
                    waypoint_threshold = 0.40
                
                if dist_to_waypoint < waypoint_threshold and not is_final_waypoint:
                    self._current_waypoint_idx += 1
                    self._tobox_wp_start_time = current_time  # Reset timeout for next waypoint
                    next_wp = self._route_waypoints[self._current_waypoint_idx] if self._current_waypoint_idx < len(self._route_waypoints) else self.active_goal
                    print(f"[TO_BOX] Waypoint {self._current_waypoint_idx}/{len(self._route_waypoints)} reached -> next: ({next_wp[0]:.2f}, {next_wp[1]:.2f})")
                    continue

                # ===== PHASE -1: TURN-IN-PLACE =====
                if self.tobox_state == -1:
                    first_wp = self._route_waypoints[0] if self._route_waypoints else self.active_goal
                    _, angle_to_first_wp = self._distance_to_point(first_wp)

                    TURN_THRESHOLD = math.radians(60)  # Skip if already < 60°
                    TURN_TIMEOUT = 8.0

                    # Skip immediately if already facing waypoint
                    if abs(angle_to_first_wp) < TURN_THRESHOLD:
                        print(f"[TO_BOX] Phase -1: Waypoint ahead ({math.degrees(angle_to_first_wp):.0f}°), skipping turn")
                        self.tobox_state = 0
                        continue

                    # Initialize turn direction (once)
                    if self._tobox_turn_start is None:
                        self._tobox_turn_start = current_time
                        self._tobox_turn_direction = 1 if angle_to_first_wp > 0 else -1
                        self._tobox_reverse_done = False
                        print(f"[TO_BOX] Phase -1: Turn {'LEFT' if angle_to_first_wp > 0 else 'RIGHT'} ({math.degrees(angle_to_first_wp):.0f}°)")

                    turn_elapsed = current_time - self._tobox_turn_start

                    # Re-check angle (may have rotated enough)
                    if abs(angle_to_first_wp) < TURN_THRESHOLD:
                        print(f"[TO_BOX] Phase -1: Turn complete ({math.degrees(angle_to_first_wp):.0f}°)")
                        self.tobox_state = 0
                        self._tobox_turn_start = None
                        continue

                    # Timeout protection
                    if turn_elapsed > TURN_TIMEOUT:
                        print(f"[TO_BOX] Phase -1: Turn timeout ({turn_elapsed:.1f}s), proceeding anyway")
                        self.tobox_state = 0
                        self._tobox_turn_start = None
                        continue

                    # FIX: Check rear clearance before rotating (avoid rear wheel stuck)
                    # When turning left (omega > 0), rear swings right
                    # When turning right (omega < 0), rear swings left
                    MIN_REAR_CLEARANCE = 0.35
                    need_reverse = False

                    if self._tobox_turn_direction > 0:  # Turning left
                        if right_obs < MIN_REAR_CLEARANCE or rear_min < MIN_REAR_CLEARANCE:
                            need_reverse = True
                    else:  # Turning right
                        if left_obs < MIN_REAR_CLEARANCE or rear_min < MIN_REAR_CLEARANCE:
                            need_reverse = True

                    # Also check front - if too close, reverse first
                    if min(front_obs, fl_obs, fr_obs) < 0.25:
                        need_reverse = True

                    # Reverse phase (first 1.5s if needed)
                    if need_reverse and not self._tobox_reverse_done:
                        if turn_elapsed < 1.5:
                            self._safe_move(-0.08, 0.0, 0.0)
                            self._log_throttled("phase1_reverse", f"[TO_BOX] Phase -1: Reversing for clearance...", 0.5)
                            continue
                        else:
                            self._tobox_reverse_done = True
                            print(f"[TO_BOX] Phase -1: Reverse done, starting turn")

                    # Execute pure rotation
                    omega = 0.45 * self._tobox_turn_direction
                    self._safe_move(0.0, 0.0, omega)
                    continue

                if self.tobox_state == 0:
                    min_front = min(front_obs, fl_obs, fr_obs)
                    left_blocked = left_obs < 0.25  # Increased from 0.20
                    right_blocked = right_obs < 0.25
                    rear_clear = rear_min > 0.30

                    # ===== WAYPOINT TIMEOUT (CAR-LIKE - NO ESCAPE MODE) =====
                    # Trust fuzzy logic for obstacle avoidance. Only skip waypoint after long timeout.
                    if not hasattr(self, '_tobox_wp_start_time') or self._tobox_wp_start_time is None:
                        self._tobox_wp_start_time = current_time
                    if not hasattr(self, '_tobox_wp_skips') or self._tobox_wp_skips is None:
                        self._tobox_wp_skips = 0

                    wp_elapsed = current_time - self._tobox_wp_start_time

                    # Skip waypoint after 15 seconds (truly stuck)
                    if wp_elapsed > 15.0:
                        self._tobox_wp_skips = getattr(self, '_tobox_wp_skips', 0) + 1
                        print(f"[TO_BOX] WP{self._current_waypoint_idx + 1} timeout ({wp_elapsed:.1f}s), skipping (total: {self._tobox_wp_skips})")
                        self._current_waypoint_idx += 1
                        self._tobox_wp_start_time = current_time

                        # Re-route after 3 skips
                        if self._tobox_wp_skips >= 3:
                            print("[TO_BOX] Too many skips! Triggering escape maneuver.")
                            # Instead of just re-routing, enter escape mode
                            self._tobox_escape_phase = 0  # 0=reverse, 1=strafe, 2=re-route
                            self._tobox_escape_start = current_time
                            self._tobox_escape_count = getattr(self, '_tobox_escape_count', 0) + 1
                            # Determine escape direction based on obstacles
                            self._tobox_escape_dir = 1 if left_obs > right_obs else -1
                            self._tobox_wp_skips = 0
                        continue

                    # ===== ESCAPE MANEUVER (when stuck in obstacle loop) =====
                    # Full bypass: reverse → rotate 60° → advance → re-route
                    if hasattr(self, '_tobox_escape_phase') and self._tobox_escape_phase is not None:
                        escape_elapsed = current_time - self._tobox_escape_start
                        escape_count = getattr(self, '_tobox_escape_count', 0)

                        # Safety: if too many escapes, drop cube and return
                        if escape_count > 5:
                            print(f"[TO_BOX] ABORT: {escape_count} escape attempts failed! Dropping cube.")
                            self._tobox_escape_phase = None
                            self._tobox_escape_count = 0
                            self.state = "DROP"
                            self.drop_state = 0
                            continue

                        if self._tobox_escape_phase == 0:
                            # Phase 0: Reverse (0.6s)
                            if escape_elapsed < 0.6:
                                self._safe_move(-0.12, 0.0, 0.0)
                                self._log_throttled("escape_rev", f"[TO_BOX] ESCAPE {escape_count}: Reversing...", 0.3)
                                continue
                            else:
                                self._tobox_escape_phase = 1
                                self._tobox_escape_start = current_time
                                # Record start heading for rotation tracking
                                self._tobox_escape_start_yaw = self.pose[2]

                        if self._tobox_escape_phase == 1:
                            # Phase 1: Rotate 60° toward clear side (1.2s max)
                            rotation_target = math.radians(60) * self._tobox_escape_dir
                            current_rotation = wrap_angle(self.pose[2] - self._tobox_escape_start_yaw)
                            rotation_done = abs(current_rotation) >= math.radians(50)

                            if escape_elapsed < 1.2 and not rotation_done:
                                omega = 0.5 * self._tobox_escape_dir
                                self._safe_move(-0.02, 0.0, omega)  # Slight reverse while rotating
                                dir_name = "LEFT" if self._tobox_escape_dir > 0 else "RIGHT"
                                self._log_throttled("escape_rot", f"[TO_BOX] ESCAPE {escape_count}: Rotating {dir_name} ({math.degrees(current_rotation):.0f}°)...", 0.3)
                                continue
                            else:
                                print(f"[TO_BOX] ESCAPE {escape_count}: Rotated {math.degrees(current_rotation):.0f}°")
                                self._tobox_escape_phase = 2
                                self._tobox_escape_start = current_time

                        if self._tobox_escape_phase == 2:
                            # Phase 2: Advance forward in new direction (1.0s)
                            if escape_elapsed < 1.0:
                                # Check if front is clear enough
                                if min_front > 0.25:
                                    self._safe_move(0.14, 0.0, 0.0)  # Forward
                                    self._log_throttled("escape_adv", f"[TO_BOX] ESCAPE {escape_count}: Advancing...", 0.3)
                                else:
                                    # Front blocked, strafe instead
                                    vy = 0.10 * self._tobox_escape_dir
                                    self._safe_move(0.0, vy, 0.0)
                                    self._log_throttled("escape_strafe", f"[TO_BOX] ESCAPE {escape_count}: Front blocked, strafing...", 0.3)
                                continue
                            else:
                                self._tobox_escape_phase = 3

                        if self._tobox_escape_phase == 3:
                            # Phase 3: Re-route from new position
                            print(f"[TO_BOX] ESCAPE {escape_count}: Complete. Re-routing from ({self.pose[0]:.2f}, {self.pose[1]:.2f})")
                            self._route_waypoints = get_route_to_box(
                                (self.pose[0], self.pose[1]), self.current_color
                            )
                            self._current_waypoint_idx = 0
                            self._tobox_escape_phase = None
                            self.tobox_state = -1
                            self._tobox_turn_start = None
                            self._tobox_wp_start_time = current_time
                            continue

                    waypoints_remaining = len(self._route_waypoints) - self._current_waypoint_idx
                    approaching_box = waypoints_remaining <= 3 or dist_to_box < 1.0

                    if approaching_box:
                        # FIXED: Only use dist_to_box, NOT min_front (which triggers on obstacles)
                        if dist_to_box < 0.55:
                            print(f"[TO_BOX] Arrived at box (dist={dist_to_box:.2f}m). Starting alignment.")
                            self._safe_move(0.0, 0.0, 0.0)
                            self.tobox_state = 1
                            self._tobox_maneuver_timer = 0.0
                            self._align_start_time = None
                            # Cleanup timeout tracking, escape state, and turn-in-place state
                            for attr in ['_tobox_wp_start_time', '_tobox_wp_skips',
                                         '_tobox_turn_start', '_tobox_turn_direction',
                                         '_tobox_escape_phase', '_tobox_escape_start',
                                         '_tobox_escape_dir', '_tobox_escape_count',
                                         '_tobox_escape_start_yaw']:
                                if hasattr(self, attr):
                                    delattr(self, attr)
                            continue

                        # Check rear clearance before rotating
                        if (left_obs < 0.30 or right_obs < 0.30 or rear_min < 0.30) and min_front > 0.30:
                            self._safe_move(0.06, 0.0, 0.0)
                            self._log_throttled("approach_rear", f"[TO_BOX] Rear blocked near box, moving forward", 1.0)
                            continue

                        cmd_omega = -angle_to_waypoint * 1.2
                        cmd_omega = max(-0.35, min(0.35, cmd_omega))
                        cmd_speed = 0.12

                        if left_blocked:
                            cmd_omega = min(cmd_omega - 0.15, -0.20)
                        if right_blocked:
                            cmd_omega = max(cmd_omega + 0.15, 0.20)

                        self._safe_move(cmd_speed, 0.0, cmd_omega)
                        continue

                    # ===== WAYPOINT-DIRECTED NAVIGATION =====
                    # Primary: steer toward waypoint. Secondary: avoid obstacles.

                    FRONT_EMERGENCY = 0.22
                    FRONT_DANGER = 0.35
                    FRONT_WARN = 0.55
                    MIN_REAR_FOR_TURN = 0.30

                    # FIX: Check rear clearance before rotating (prevents rear wheel stuck)
                    # If rear/side blocked, need to get clearance first
                    rear_blocked_left = left_obs < MIN_REAR_FOR_TURN
                    rear_blocked_right = right_obs < MIN_REAR_FOR_TURN
                    rear_blocked = rear_min < MIN_REAR_FOR_TURN
                    any_rear_blocked = rear_blocked or rear_blocked_left or rear_blocked_right

                    if any_rear_blocked:
                        if min_front > 0.30:
                            # Rear stuck, front clear - move forward to clear
                            self._safe_move(0.06, 0.0, 0.0)
                            self._log_throttled("rear_clear", f"[TO_BOX] Rear blocked, moving forward", 1.0)
                            continue
                        elif min_front < FRONT_EMERGENCY:
                            # BOTH blocked - strafe to escape
                            if left_obs > right_obs:
                                self._safe_move(0.0, 0.08, 0.0)
                                self._log_throttled("stuck_strafe", f"[TO_BOX] STUCK! Strafing LEFT", 0.5)
                            else:
                                self._safe_move(0.0, -0.08, 0.0)
                                self._log_throttled("stuck_strafe", f"[TO_BOX] STUCK! Strafing RIGHT", 0.5)
                            continue

                    # FIX: Strong frontal obstacle avoidance using LIDAR
                    # If obstacle in front, MUST turn away before moving forward
                    if min_front < FRONT_DANGER:
                        # CRITICAL: Don't try to go through obstacles!
                        # Turn toward clearer side, don't just slow down
                        if min_front < FRONT_EMERGENCY:
                            # Emergency: reverse
                            vx = -0.08 if rear_clear else 0.0
                            self._log_throttled("tobox_emergency", f"[TO_BOX] EMERGENCY obstacle at {min_front:.2f}m, reversing!", 0.5)
                        else:
                            vx = 0.0  # STOP forward motion when obstacle close
                            self._log_throttled("tobox_obstacle", f"[TO_BOX] Obstacle at {min_front:.2f}m, turning away", 1.0)

                        # Turn toward clearer side (OVERRIDE waypoint direction)
                        if fl_obs < fr_obs:
                            # Left blocked, turn RIGHT
                            omega = -0.35
                        elif fr_obs < fl_obs:
                            # Right blocked, turn LEFT
                            omega = 0.35
                        else:
                            # Both equal - turn toward waypoint but slowly
                            omega = -angle_to_waypoint * 0.5
                            omega = max(-0.3, min(0.3, omega))

                        # Also strafe away from closest side
                        vy = 0.0
                        if left_obs < 0.30:
                            vy = -0.06
                        elif right_obs < 0.30:
                            vy = 0.06

                        self._safe_move(vx, vy, omega)
                        continue

                    # Normal navigation: steer toward waypoint
                    # 1. Calculate rotation to face waypoint (PRIORITY)
                    omega = -angle_to_waypoint * 1.2  # Proportional control
                    omega = max(-0.4, min(0.4, omega))

                    # 2. Calculate forward speed based on alignment
                    if min_front < FRONT_WARN:
                        vx = 0.08
                        # Mild correction toward clearer side
                        if fl_obs < fr_obs - 0.1:
                            omega = max(omega - 0.1, -0.4)
                        elif fr_obs < fl_obs - 0.1:
                            omega = min(omega + 0.1, 0.4)
                    else:
                        # Clear path - full speed adjusted by turn
                        vx = 0.14 * (1.0 - min(0.5, abs(omega) / 0.4))

                    # 3. Minimal lateral correction (only when obstacle very close)
                    vy = 0.0
                    if left_obs < 0.25 and right_obs > 0.35:
                        vy = -0.04  # Strafe away from left obstacle
                    elif right_obs < 0.25 and left_obs > 0.35:
                        vy = 0.04   # Strafe away from right obstacle

                    self._safe_move(vx, vy, omega)

                elif self.tobox_state == 1:
                    if self._align_start_time is None:
                        self._align_start_time = self.robot.getTime()
                    
                    align_elapsed = self.robot.getTime() - self._align_start_time
                    
                    if self.current_color == "green":
                        target_heading = math.pi / 2
                    elif self.current_color == "blue":
                        target_heading = -math.pi / 2
                    else:
                        target_heading = 0.0
                    
                    heading_error = wrap_angle(target_heading - self.pose[2])
                    
                    if align_elapsed < 0.1:
                        print(f"[TO_BOX] Alignment: error={math.degrees(heading_error):.0f}°")
                    
                    ALIGN_TOLERANCE = 0.20  # ~11° (was 0.44 = 25°)
                    ALIGN_TIMEOUT = 2.5

                    if abs(heading_error) < ALIGN_TOLERANCE:
                        # Check lateral centering using side sensors
                        left_lateral = lateral_info.get("left", 1.0)
                        right_lateral = lateral_info.get("right", 1.0)
                        lateral_diff = abs(left_lateral - right_lateral)

                        if lateral_diff < 0.15:  # Centered enough
                            print(f"[TO_BOX] Alignment OK (heading={math.degrees(heading_error):.0f}°, lat_diff={lateral_diff:.2f})")
                            self.tobox_state = 2
                            self._approach_start_time = None
                            continue
                        else:
                            # Correct lateral drift
                            if left_lateral < right_lateral:
                                self._safe_move(0.0, -0.06, 0.0)  # Strafe right
                            else:
                                self._safe_move(0.0, 0.06, 0.0)   # Strafe left
                            print(f"[TO_BOX] Centering: L={left_lateral:.2f}, R={right_lateral:.2f}")
                            continue
                    
                    if align_elapsed > ALIGN_TIMEOUT:
                        print(f"[TO_BOX] Alignment timeout. Proceeding (error={math.degrees(heading_error):.0f}°).")
                        self.tobox_state = 2
                        self._approach_start_time = None
                        continue

                    omega = heading_error * 0.5
                    omega = max(-0.25, min(0.25, omega))
                    
                    self._safe_move(0.0, 0.0, omega)

                elif self.tobox_state == 2:
                    ds_val = front_info["front"]
                    
                    if self._approach_start_time is None:
                        self._approach_start_time = self.robot.getTime()
                        print(f"[TO_BOX] Starting approach. Front sensor: {ds_val:.3f}m")
                    
                    approach_elapsed = self.robot.getTime() - self._approach_start_time
                    
                    if int(approach_elapsed * 2) % 2 == 0 and approach_elapsed > 0.5:
                        if not hasattr(self, '_last_approach_log') or self._last_approach_log != int(approach_elapsed):
                            self._last_approach_log = int(approach_elapsed)
                            print(f"[TO_BOX] Approaching: ds={ds_val:.3f}m, dist_box={dist_to_box:.2f}m")
                    
                    drop_ready = (0.40 < ds_val < 0.55)  # Tighter window
                    timeout_drop = (approach_elapsed > 4.0 and dist_to_box < 0.65)
                    
                    if drop_ready or timeout_drop:
                        if timeout_drop and not drop_ready:
                            print(f"[TO_BOX] Approach timeout (ds={ds_val:.3f}m). DROP.")
                        else:
                            print(f"[TO_BOX] Final position (ds={ds_val:.3f}m). Executing DROP.")
                        self._safe_move(0.0, 0.0, 0.0)
                        self._start_drop()
                        for attr in ['tobox_state', '_tobox_maneuver_timer', '_align_start_time', 
                                     '_approach_start_time', '_route_waypoints', '_current_waypoint_idx',
                                     '_last_pos_log_time', '_last_approach_log']:
                            if hasattr(self, attr):
                                delattr(self, attr)
                        continue

                    if ds_val < 0.35:
                        print(f"[TO_BOX] Too close ({ds_val:.3f}m). Safety DROP.")
                        self._safe_move(0.0, 0.0, 0.0)
                        self._start_drop()
                        for attr in ['tobox_state', '_tobox_maneuver_timer', '_route_waypoints', 
                                     '_current_waypoint_idx', '_last_pos_log_time']:
                            if hasattr(self, attr):
                                delattr(self, attr)
                        continue

                    if ds_val > 0.50:
                        speed = 0.08
                    elif ds_val > 0.35:
                        speed = 0.05
                    else:
                        speed = 0.03
                    
                    omega = -angle_to_box * 1.0
                    omega = max(-0.20, min(0.20, omega))
                    
                    self._safe_move(speed, 0.0, omega)
                
                continue

            # ===== MODE: DROP =====
            if self.mode == "drop":
                self._handle_drop(dt)
                continue

            # ===== MODE: RETURN_TO_SPAWN =====
            if self.mode == "return_to_spawn":
                self._handle_return_to_spawn(dt, lidar_info, rear_info, lateral_info, front_info)
                continue

